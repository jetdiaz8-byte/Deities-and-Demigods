/**
 * DDG Campaign Worker v3
 * KV binding: DDG_DB
 * Routes:
 *   POST /proxy/groq         Groq API proxy
 *   GET  /db/:id             Entity by id or name
 *   GET  /db/:cat/:id        Entity by category + id
 *   GET  /db/list/:cat       All ids in category
 *   GET  /db/search/:query   Search by name/pantheon (uses prebuilt index)
 *   GET  /db/random/:cat     Random entity from category
 */
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Groq-Key',
};
const j = (d, s=200) => new Response(JSON.stringify(d), {
  status:s, headers:{'Content-Type':'application/json',...CORS}
});
const CATS = ['heroes','demigods','lesser_gods','monsters'];

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null,{status:204,headers:CORS});
    const url  = new URL(req.url);
    const path = url.pathname;

    // POST /proxy/groq
    if (path === '/proxy/groq' && req.method === 'POST') {
      try {
        const key  = req.headers.get('X-Groq-Key')||'';
        const body = await req.json();
        const r    = await fetch('https://api.groq.com/openai/v1/chat/completions',{
          method:'POST',
          headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},
          body:JSON.stringify(body)
        });
        return j(await r.json(), r.status);
      } catch(e){ return j({error:e.message},500); }
    }

    // GET /db/list/:cat
    if (path.startsWith('/db/list/')) {
      const cat = path.replace('/db/list/','').toLowerCase();
      try {
        const list = await env.DDG_DB.list({prefix:cat+':'});
        return j(list.keys.map(k=>k.name.replace(cat+':','')));
      } catch(e){ return j({error:e.message},500); }
    }

    // GET /db/random/:cat
    if (path.startsWith('/db/random/')) {
      const cat = path.replace('/db/random/','').toLowerCase();
      try {
        const list = await env.DDG_DB.list({prefix:cat+':'});
        if(!list.keys.length) return j({error:'No entities in category'},404);
        const key = list.keys[Math.floor(Math.random()*list.keys.length)].name;
        return j(await env.DDG_DB.get(key,'json'));
      } catch(e){ return j({error:e.message},500); }
    }

    // GET /db/search/:query — uses prebuilt search:all index
    if (path.startsWith('/db/search/')) {
      const query = decodeURIComponent(path.replace('/db/search/','')).toLowerCase();
      try {
        const idx = await env.DDG_DB.get('search:all','json');
        if (!idx) return j({error:'Search index not loaded. Run add_search_index.py'},503);
        const norm = query.replace(/[^a-z0-9]/g,'');
        const results = (idx.entities||[]).filter(e =>
          e.name.toLowerCase().replace(/[^a-z0-9]/g,'').includes(norm) ||
          (e.pantheon||'').toLowerCase().replace(/[^a-z0-9]/g,'').includes(norm) ||
          (e.align||'').toLowerCase().replace(/[^a-z0-9]/g,'').includes(norm) ||
          e.id.replace(/[^a-z0-9]/g,'').includes(norm) ||
          (e.type||'').toLowerCase().replace(/[^a-z0-9]/g,'').includes(norm)
        );
        return j(results);
      } catch(e){ return j({error:e.message},500); }
    }

    // GET /db/:cat/:id  or  /db/:id
    if (path.startsWith('/db/')) {
      const parts = path.replace('/db/','').split('/').filter(Boolean);
      try {
        let entity = null;
        if (parts.length >= 2) {
          entity = await env.DDG_DB.get(parts[0]+':'+parts[1],'json');
        } else if (parts.length === 1) {
          const id = parts[0].toLowerCase();
          // Direct id lookup across all categories
          for (const cat of CATS) {
            entity = await env.DDG_DB.get(cat+':'+id,'json');
            if (entity) break;
          }
          // Name search via index if not found by id
          if (!entity) {
            const idx = await env.DDG_DB.get('search:all','json');
            if (idx) {
              const norm = id.replace(/[^a-z0-9]/g,'');
              const match = (idx.entities||[]).find(e =>
                e.name.toLowerCase().replace(/[^a-z0-9]/g,'').includes(norm)
              );
              if (match) {
                entity = await env.DDG_DB.get(match.category+':'+match.id,'json');
              }
            }
          }
        }
        if (!entity) return j({error:'Not found',query:parts.join('/')},404);
        return j(entity);
      } catch(e){ return j({error:e.message},500); }
    }

    // GET /
    return j({
      service:'DDG Campaign Worker v3',
      database:'156 entities from TSR Deities & Demigods (1980)',
      routes:{
        'POST /proxy/groq':'Groq API proxy (X-Groq-Key header)',
        'GET /db/:id':'Entity by id or name',
        'GET /db/:cat/:id':'Entity by category+id',
        'GET /db/list/:cat':'List ids (heroes/demigods/lesser_gods/monsters)',
        'GET /db/search/:query':'Search by name, pantheon, alignment, type',
        'GET /db/random/:cat':'Random entity from category',
      }
    });
  }
};
